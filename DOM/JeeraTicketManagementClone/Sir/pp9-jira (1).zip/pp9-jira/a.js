let x = 10;
let str = "asjnxdkjasnxnaskj" + x + "xnasjknxanskxnask";

// ---------------------------------------

let str2 = `asdjknasjndasdnkasndnaskndjkansk
asldhnjklasndjknaskjdnkasjn    ${x}
askjdbnjkasnbdjknasjkndjkasnkdj
askljdnjkasndjknasjkdnaskndkjnas
alsijdlasndasnjd`;

console.log(str);
console.log();
console.log();
console.log();
console.log();
console.log(str2);
